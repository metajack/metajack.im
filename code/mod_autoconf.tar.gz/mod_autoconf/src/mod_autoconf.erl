-module(mod_autoconf).
-author("Jack Moffitt <metajack@gmail.com>").

-behavior(gen_mod).

% gen_mod exports
-export([start/2, stop/1]).

% gen_mod behavior implementation

start(_Host, _Opts) ->
    ok.

stop(_Host) ->
    ok.
